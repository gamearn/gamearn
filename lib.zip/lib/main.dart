import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:provider/provider.dart';
import 'firebase_options.dart';

// ==================== MAIN ====================
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  runApp(const GamingPlatformApp());
}

class GamingPlatformApp extends StatelessWidget {
  const GamingPlatformApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        StreamProvider<User?>(
          create: (_) => FirebaseAuth.instance.authStateChanges(),
          initialData: null,
        ),
        StreamProvider<DocumentSnapshot?>(
          create: (context) {
            final user = context.read<User?>();
            if (user == null) return Stream.value(null);
            return FirebaseFirestore.instance
                .collection('users')
                .doc(user.uid)
                .snapshots();
          },
          initialData: null,
        ),
      ],
      child: MaterialApp(
        title: 'Gaming Platform',
        debugShowCheckedModeBanner: false,
        theme: ThemeData.dark().copyWith(
          colorScheme: ColorScheme.fromSeed(
              seedColor: Colors.deepPurple, brightness: Brightness.dark),
          useMaterial3: true,
        ),
        home: const AuthWrapper(),
      ),
    );
  }
}

// ==================== AUTH WRAPPER (decides where to go) ====================
class AuthWrapper extends StatelessWidget {
  const AuthWrapper({super.key});

  @override
  Widget build(BuildContext context) {
    final user = context.watch<User?>();
    final userDoc = context.watch<DocumentSnapshot?>();

    if (user == null) {
      return const LoginScreen();
    }
    if (userDoc == null || !userDoc.exists) {
      return const CreateProfileScreen();
    }

    final isAdmin = userDoc.get('isAdmin') ?? false;
    if (isAdmin) {
      return const AdminDashboard();
    } else {
      return const UserApp(); // we will build this in next message
    }
  }
}

// ==================== LOGIN SCREEN ====================
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  bool _isLoading = false;

  Future<void> _login() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _isLoading = true);
    try {
      await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: _emailController.text.trim(),
        password: _passwordController.text,
      );
    } on FirebaseAuthException catch (e) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(e.message ?? 'Login failed')));
    } finally {
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Colors.deepPurple, Colors.purpleAccent]),
        ),
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Form(
              key: _formKey,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.sports_esports,
                      size: 80, color: Colors.white),
                  const SizedBox(height: 24),
                  const Text('GAMING PLATFORM',
                      style: TextStyle(
                          fontSize: 28,
                          fontWeight: FontWeight.bold,
                          color: Colors.white)),
                  const SizedBox(height: 48),
                  TextFormField(
                    controller: _emailController,
                    decoration: const InputDecoration(
                        labelText: 'Email',
                        filled: true,
                        fillColor: Colors.white12),
                    validator: (v) =>
                        v!.contains('@') ? null : 'Enter valid email',
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: _passwordController,
                    obscureText: true,
                    decoration: const InputDecoration(
                        labelText: 'Password',
                        filled: true,
                        fillColor: Colors.white12),
                    validator: (v) =>
                        v!.length >= 6 ? null : 'Min 6 characters',
                  ),
                  const SizedBox(height: 24),
                  _isLoading
                      ? const CircularProgressIndicator()
                      : ElevatedButton(
                          onPressed: _login,
                          style: ElevatedButton.styleFrom(
                              minimumSize: const Size(double.infinity, 50)),
                          child: const Text('LOGIN'),
                        ),
                  TextButton(
                    onPressed: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => const RegisterScreen())),
                    child: const Text("Don't have an account? Register"),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ==================== REGISTER SCREEN ====================
class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  Future<void> _register() async {
    if (!_formKey.currentState!.validate()) return;
    try {
      await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: _emailController.text.trim(),
        password: _passwordController.text,
      );
      // The AuthWrapper will redirect to CreateProfileScreen
    } on FirebaseAuthException catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.message ?? 'Registration failed')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
            gradient: LinearGradient(
                colors: [Colors.deepPurple, Colors.purpleAccent])),
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Form(
              key: _formKey,
              child: Column(
                children: [
                  const Icon(Icons.app_registration,
                      size: 80, color: Colors.white),
                  const SizedBox(height: 24),
                  const Text('Create Account',
                      style: TextStyle(
                          fontSize: 28,
                          fontWeight: FontWeight.bold,
                          color: Colors.white)),
                  const SizedBox(height: 48),
                  TextFormField(
                    controller: _emailController,
                    decoration: const InputDecoration(
                        labelText: 'Email',
                        filled: true,
                        fillColor: Colors.white12),
                    validator: (v) =>
                        v!.contains('@') ? null : 'Enter valid email',
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: _passwordController,
                    obscureText: true,
                    decoration: const InputDecoration(
                        labelText: 'Password',
                        filled: true,
                        fillColor: Colors.white12),
                    validator: (v) =>
                        v!.length >= 6 ? null : 'Min 6 characters',
                  ),
                  const SizedBox(height: 24),
                  ElevatedButton(
                    onPressed: _register,
                    style: ElevatedButton.styleFrom(
                        minimumSize: const Size(double.infinity, 50)),
                    child: const Text('REGISTER'),
                  ),
                  TextButton(
                      onPressed: () => Navigator.pop(context),
                      child: const Text('Back to Login')),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ==================== CREATE PROFILE SCREEN (after registration) ====================
class CreateProfileScreen extends StatefulWidget {
  const CreateProfileScreen({super.key});

  @override
  State<CreateProfileScreen> createState() => _CreateProfileScreenState();
}

class _CreateProfileScreenState extends State<CreateProfileScreen> {
  final _usernameController = TextEditingController();
  bool _isAdmin =
      false; // only you can set this manually (e.g., via hidden toggle)
  bool _isLoading = false;

  Future<void> _createProfile() async {
    if (_usernameController.text.trim().isEmpty) return;
    setState(() => _isLoading = true);
    final user = FirebaseAuth.instance.currentUser!;
    await FirebaseFirestore.instance.collection('users').doc(user.uid).set({
      'username': _usernameController.text.trim(),
      'email': user.email,
      'isAdmin': _isAdmin,
      'createdAt': FieldValue.serverTimestamp(),
      'status': 'active',
      'walletCoins': 0,
      'streak': 0,
      'stats': {'played': 0, 'won': 0, 'lost': 0},
    });
    setState(() => _isLoading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
            gradient: LinearGradient(
                colors: [Colors.deepPurple, Colors.purpleAccent])),
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.person_add, size: 80, color: Colors.white),
                const SizedBox(height: 24),
                const Text('Complete Profile',
                    style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Colors.white)),
                const SizedBox(height: 32),
                TextField(
                  controller: _usernameController,
                  decoration: const InputDecoration(
                      labelText: 'Username',
                      filled: true,
                      fillColor: Colors.white12),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Checkbox(
                        value: _isAdmin,
                        onChanged: (val) =>
                            setState(() => _isAdmin = val ?? false)),
                    const Text('Admin Access (hidden toggle)',
                        style: TextStyle(color: Colors.white70)),
                  ],
                ),
                const SizedBox(height: 24),
                _isLoading
                    ? const CircularProgressIndicator()
                    : ElevatedButton(
                        onPressed: _createProfile,
                        style: ElevatedButton.styleFrom(
                            minimumSize: const Size(double.infinity, 50)),
                        child: const Text('START GAMING'),
                      ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ==================== ADMIN DASHBOARD (matching Figma) ====================
class AdminDashboard extends StatefulWidget {
  const AdminDashboard({super.key});

  @override
  State<AdminDashboard> createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
  int _selectedIndex = 0; // 0:Admin, 1:Users, 2:Tour, 3:Arena

  final List<Widget> _screens = [
    const AdminStatsScreen(),
    const UserManagementScreen(),
    const TournamentOverviewScreen(),
    const ArenaAnalyticsScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _screens[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        backgroundColor: Colors.deepPurple.shade900,
        selectedItemColor: Colors.deepPurpleAccent,
        unselectedItemColor: Colors.grey,
        currentIndex: _selectedIndex,
        onTap: (index) => setState(() => _selectedIndex = index),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.dashboard), label: 'Admin'),
          BottomNavigationBarItem(icon: Icon(Icons.people), label: 'Users'),
          BottomNavigationBarItem(
              icon: Icon(Icons.emoji_events), label: 'Tour'),
          BottomNavigationBarItem(
              icon: Icon(Icons.analytics), label: 'Arena'), // ✅ fixed
        ],
      ),
    );
  }
}

// ==================== STATS SCREEN (TOTAL TRANSACTIONS, COMPLETED GAMES etc) ====================
class AdminStatsScreen extends StatelessWidget {
  const AdminStatsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: const Text('Admin Dashboard'),
          backgroundColor: Colors.deepPurple),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                    child: _StatsCard(
                        title: 'TOTAL USERS',
                        value: '125,430',
                        trend: '+12.5% VS LAST MONTH',
                        onTap: () {})),
                const SizedBox(width: 16),
                Expanded(
                    child: _StatsCard(
                        title: 'LIVE USERS',
                        value: '4,250',
                        subtitle: 'ACTIVE NOW',
                        onTap: () {})),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                    child: _StatsCard(
                        title: 'TOTAL TRANSACTIONS',
                        value: '₦45.2M',
                        subtitle: 'PROCESSING ₦2.1M DAILY',
                        onTap: () {})),
                const SizedBox(width: 16),
                Expanded(
                    child: _StatsCard(
                        title: 'COMPLETED GAMES',
                        value: '892,104',
                        subtitle: 'ACROSS 14 CATEGORIES',
                        onTap: () {})),
              ],
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                  color: Colors.grey.shade900,
                  borderRadius: BorderRadius.circular(16)),
              child: Row(
                children: [
                  const Icon(Icons.shield, color: Colors.green),
                  const SizedBox(width: 8),
                  const Text('Anti-Cheat Neural Link Active'),
                  const Spacer(),
                  const Icon(Icons.warning_amber, color: Colors.orange),
                  const SizedBox(width: 8),
                  const Text('Identity Verification Required'),
                  const Spacer(),
                  const Icon(Icons.gavel, color: Colors.red),
                  const SizedBox(width: 8),
                  const Text('Tournament Rules Enforced'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _StatsCard extends StatelessWidget {
  final String title;
  final String value;
  final String? subtitle;
  final String? trend;
  final VoidCallback onTap;

  const _StatsCard(
      {required this.title,
      required this.value,
      this.subtitle,
      this.trend,
      required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
            color: Colors.grey.shade900,
            borderRadius: BorderRadius.circular(16)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title,
                style: const TextStyle(fontSize: 14, color: Colors.grey)),
            const SizedBox(height: 8),
            Text(value,
                style:
                    const TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
            if (subtitle != null)
              Text(subtitle!,
                  style: const TextStyle(fontSize: 12, color: Colors.grey)),
            if (trend != null)
              Text(trend!,
                  style: const TextStyle(fontSize: 12, color: Colors.green)),
            const SizedBox(height: 8),
            const Text('VIEW DETAILS',
                style: TextStyle(fontSize: 12, color: Colors.deepPurpleAccent)),
          ],
        ),
      ),
    );
  }
}

// ==================== USER MANAGEMENT SCREEN (matching Figma) ====================
class UserManagementScreen extends StatefulWidget {
  const UserManagementScreen({super.key});

  @override
  State<UserManagementScreen> createState() => _UserManagementScreenState();
}

class _UserManagementScreenState extends State<UserManagementScreen> {
  String _searchQuery = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: const Text('Total Users Management'),
          backgroundColor: Colors.deepPurple),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    onChanged: (val) =>
                        setState(() => _searchQuery = val.toLowerCase()),
                    decoration: const InputDecoration(
                      hintText: 'SEARCH BY USERNAME OR ID...',
                      prefixIcon: Icon(Icons.search),
                      suffixIcon: Icon(Icons.filter_list),
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream:
                  FirebaseFirestore.instance.collection('users').snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData)
                  return const Center(child: CircularProgressIndicator());
                var users = snapshot.data!.docs;
                if (_searchQuery.isNotEmpty) {
                  users = users.where((doc) {
                    final username =
                        doc.get('username').toString().toLowerCase();
                    final uid = doc.id.toLowerCase();
                    return username.contains(_searchQuery) ||
                        uid.contains(_searchQuery);
                  }).toList();
                }
                return ListView.builder(
                  itemCount: users.length,
                  itemBuilder: (context, index) {
                    final doc = users[index];
                    final data = doc.data() as Map<String, dynamic>;
                    return _UserCard(docId: doc.id, data: data);
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _UserCard extends StatefulWidget {
  final String docId;
  final Map<String, dynamic> data;
  const _UserCard({required this.docId, required this.data});

  @override
  State<_UserCard> createState() => _UserCardState();
}

class _UserCardState extends State<_UserCard> {
  Future<void> _suspendUser() async {
    final newStatus =
        widget.data['status'] == 'active' ? 'suspended' : 'active';
    await FirebaseFirestore.instance
        .collection('users')
        .doc(widget.docId)
        .update({'status': newStatus});
    setState(() {});
  }

  Future<void> _deleteUser() async {
    await FirebaseFirestore.instance
        .collection('users')
        .doc(widget.docId)
        .delete();
  }

  @override
  Widget build(BuildContext context) {
    final stats = widget.data['stats'] as Map<String, dynamic>? ??
        {'played': 0, 'won': 0, 'lost': 0};
    final streak = widget.data['streak'] ?? 0;
    final status = widget.data['status'] ?? 'active';
    final joinedAt = (widget.data['createdAt'] as Timestamp?)?.toDate();
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      child: ExpansionTile(
        leading:
            CircleAvatar(child: Text(widget.data['username'][0].toUpperCase())),
        title: Text(widget.data['username']),
        subtitle: Text(widget.data['email'] ?? ''),
        trailing: Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
          decoration: BoxDecoration(
              color: status == 'active' ? Colors.green : Colors.red,
              borderRadius: BorderRadius.circular(12)),
          child: Text(status.toUpperCase(),
              style: const TextStyle(fontSize: 10, color: Colors.white)),
        ),
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    _PerfMetric(
                        label: 'Played', value: stats['played'].toString()),
                    _PerfMetric(label: 'Won', value: stats['won'].toString()),
                    _PerfMetric(label: 'Lost', value: stats['lost'].toString()),
                  ],
                ),
                const SizedBox(height: 12),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Chip(
                        label: Text('STREAK: $streak'),
                        backgroundColor: Colors.orange),
                    if (joinedAt != null)
                      Text(
                          'JOINED: ${joinedAt.toLocal().toString().split(' ')[0]}'),
                  ],
                ),
                const SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    ElevatedButton(
                      onPressed: _suspendUser,
                      style:
                          ElevatedButton.styleFrom(backgroundColor: Colors.red),
                      child: Text(
                          status == 'active' ? 'SUSPEND USER' : 'REINSTATE'),
                    ),
                    const SizedBox(width: 8),
                    OutlinedButton(
                        onPressed: _deleteUser,
                        child: const Text('DELETE PROFILE')),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _PerfMetric extends StatelessWidget {
  final String label;
  final String value;
  const _PerfMetric({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(value,
            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        Text(label, style: const TextStyle(fontSize: 12))
      ],
    );
  }
}

// ==================== TOURNAMENT OVERVIEW SCREEN ====================
class TournamentOverviewScreen extends StatefulWidget {
  const TournamentOverviewScreen({super.key});

  @override
  State<TournamentOverviewScreen> createState() =>
      _TournamentOverviewScreenState();
}

class _TournamentOverviewScreenState extends State<TournamentOverviewScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Tournament Overview'),
        backgroundColor: Colors.deepPurple,
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'ACTIVE'),
            Tab(text: 'PENDING'),
            Tab(text: 'FINALIZED')
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _TournamentList(status: 'active'),
          _TournamentList(status: 'pending'),
          _TournamentList(status: 'finalized'),
        ],
      ),
    );
  }
}

class _TournamentList extends StatelessWidget {
  final String status;
  const _TournamentList({required this.status});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('tournaments')
          .where('status', isEqualTo: status)
          .snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData)
          return const Center(child: CircularProgressIndicator());
        final docs = snapshot.data!.docs;
        if (docs.isEmpty) return const Center(child: Text('No tournaments'));
        return ListView.builder(
          itemCount: docs.length,
          itemBuilder: (context, index) {
            final data = docs[index].data() as Map<String, dynamic>;
            return Card(
              margin: const EdgeInsets.all(8),
              child: ListTile(
                title: Text(data['name'] ?? 'Tournament'),
                subtitle: Text(
                    'Participants: ${data['participants']?.length ?? 0} / 1000\nSchedule: ${data['startDate'] ?? 'TBD'} - ${data['endDate'] ?? 'TBD'}'),
                trailing: ElevatedButton(
                  onPressed: () {},
                  child: Text(
                      status == 'finalized' ? 'VIEW ARCHIVE' : 'VIEW DETAILS'),
                ),
              ),
            );
          },
        );
      },
    );
  }
}

// ==================== ARENA ANALYTICS (CHART + PIE) ====================
class ArenaAnalyticsScreen extends StatelessWidget {
  const ArenaAnalyticsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: const Text('Completed Games'),
          backgroundColor: Colors.deepPurple),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                  color: Colors.grey.shade900,
                  borderRadius: BorderRadius.circular(16)),
              child: Column(
                children: [
                  const Text('GLOBAL OPERATIONS SUMMARY',
                      style: TextStyle(color: Colors.grey)),
                  const SizedBox(height: 8),
                  const Text('COMPLETED GAMES', style: TextStyle(fontSize: 18)),
                  const Text('892,104',
                      style:
                          TextStyle(fontSize: 48, fontWeight: FontWeight.bold)),
                  const Text('~12%', style: TextStyle(color: Colors.green)),
                  const SizedBox(height: 8),
                  const Text(
                      'Aggregate game completion across all verified arena servers. Data latency 42ms.'),
                  const SizedBox(height: 16),
                  Container(
                    padding: const EdgeInsets.all(12),
                    color: Colors.green.withOpacity(0.1),
                    child: const Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('ACTIVE PLAYERS',
                            style: TextStyle(fontWeight: FontWeight.bold)),
                        Text('14,202',
                            style: TextStyle(
                                fontSize: 24, fontWeight: FontWeight.bold)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            // Placeholder for chart (in next iteration we can add fl_chart)
            Container(
              height: 200,
              decoration: BoxDecoration(
                  color: Colors.grey.shade900,
                  borderRadius: BorderRadius.circular(16)),
              child: const Center(
                  child: Text('30-DAY VELOCITY CHART (to be implemented)')),
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                  color: Colors.grey.shade900,
                  borderRadius: BorderRadius.circular(16)),
              child: Column(
                children: [
                  const Text('GAME DISTRIBUTION',
                      style: TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                          child: Container(
                              height: 150,
                              color: Colors.grey.shade800,
                              child: const Center(
                                  child: Text('Pie Chart Placeholder')))),
                      const SizedBox(width: 16),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: const [
                          _LegendItem(
                              color: Colors.red, label: 'LUDO', percent: '42%'),
                          _LegendItem(
                              color: Colors.green,
                              label: 'AYO',
                              percent: '28%'),
                          _LegendItem(
                              color: Colors.blue,
                              label: 'CHESS',
                              percent: '18%'),
                          _LegendItem(
                              color: Colors.orange,
                              label: 'DRAFT',
                              percent: '12%'),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _LegendItem extends StatelessWidget {
  final Color color;
  final String label;
  final String percent;
  const _LegendItem(
      {required this.color, required this.label, required this.percent});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Container(width: 16, height: 16, color: color),
          const SizedBox(width: 8),
          Text(label),
          const SizedBox(width: 8),
          Text(percent, style: const TextStyle(fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}

// ==================== USER APP (will be built in next message) ====================
class UserApp extends StatelessWidget {
  const UserApp({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.account_circle,
                size: 80, color: Colors.deepPurple),
            const SizedBox(height: 16),
            const Text('User App - Coming in Message 5'),
            const SizedBox(height: 8),
            Text(
                'Current user: ${FirebaseAuth.instance.currentUser?.email ?? "Not logged"}'),
          ],
        ),
      ),
    );
  }
}
